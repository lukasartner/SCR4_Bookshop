<?php
namespace Bookshop;

class User extends Entity {



    private $userName;
    private $passwordHash; 


    public function __construct(int $id, string $userName, string $passwordHash) {

        parent::__construct($id);
        $this->userName = $userName;
        $this->passwordHash = $passwordHash;

    }


    public function getUserName() : string {
        return $this->userName;
    }

    public function passwordHash() : string {
        return $this->passwordHash;
    }


}

