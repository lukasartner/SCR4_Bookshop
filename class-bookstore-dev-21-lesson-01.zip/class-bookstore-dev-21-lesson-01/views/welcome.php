<?php require_once('views/partials/header.php'); ?>

<div class="page-header">
    <h2>Welcome</h2>
</div>

<p>Welcome to SCM4 Bookshop</p>

<?php require_once('views/partials/footer.php'); ?>