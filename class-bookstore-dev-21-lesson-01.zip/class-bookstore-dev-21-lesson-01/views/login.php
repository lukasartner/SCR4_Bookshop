<?php require_once('views/partials/header.php'); ?>

<div class="page-header">
    <h2>Login</h2>
</div>



<?php require_once('views/partials/footer.php'); ?>